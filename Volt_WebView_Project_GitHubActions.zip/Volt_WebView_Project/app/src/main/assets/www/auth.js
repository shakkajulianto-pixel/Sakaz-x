/* Volt local-only account system. Data is stored on this device in WebView localStorage. */
(function () {
  const USERS_KEY = 'volt_users_v1';
  const SESSION_KEY = 'volt_session_v1';
  function readUsers() {
    try { const value = JSON.parse(localStorage.getItem(USERS_KEY) || '[]'); return Array.isArray(value) ? value : []; }
    catch (_) { return []; }
  }
  function writeUsers(users) { localStorage.setItem(USERS_KEY, JSON.stringify(users)); }
  function ensureDev() {
    const users = readUsers();
    let dev = users.find(u => String(u.username).toLowerCase() === 'sakz');
    if (!dev) users.push({ username: 'Sakz', password: '1', email: '—', userid: 'VOLT-DEV', role: 'DEV', status: 'Active', created_at: new Date().toLocaleDateString() });
    else { dev.role = 'DEV'; dev.userid = 'VOLT-DEV'; }
    writeUsers(users);
  }
  function session() { try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); } catch (_) { return null; } }
  function currentUser() {
    const s = session(); if (!s) return null;
    return readUsers().find(u => String(u.username).toLowerCase() === String(s.username).toLowerCase()) || null;
  }
  function requireLogin() {
    const user = currentUser();
    if (!user) { location.replace('index.html'); return null; }
    return user;
  }
  function safeText(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function showMessage(text) {
    let el = document.getElementById('volt-message');
    if (!el) { el = document.createElement('p'); el.id = 'volt-message'; el.style.cssText = 'color:#9ddcff;font-size:13px;line-height:1.5;margin:0;text-align:center'; const card = document.querySelector('.login-card'); (card || document.body).appendChild(el); }
    el.textContent = text;
  }
  function setupLogin() {
    const card = document.querySelector('.login-card'); if (!card) return;
    card.innerHTML = `
      <div id="volt-mode" style="color:#bde6ff;font-weight:bold;font-size:17px">Login Member</div>
      <input type="text" placeholder="Username" id="username" autocomplete="username" maxlength="24">
      <input type="password" placeholder="Password" id="password" autocomplete="current-password" maxlength="72">
      <input type="email" placeholder="Email (untuk register)" id="email" autocomplete="email" style="display:none">
      <input type="button" id="volt-submit" value="Log In">
      <button type="button" id="volt-toggle" style="background:transparent;color:#a9ddff;border:0;padding:8px">Belum punya akun? Register</button>
      <p style="font-size:11px;color:#91abc7;margin:0">Sakz adalah akun DEV bawaan.</p>`;
    let registering = false;
    const email = document.getElementById('email');
    const submit = document.getElementById('volt-submit');
    const toggle = document.getElementById('volt-toggle');
    function mode() { document.getElementById('volt-mode').textContent = registering ? 'Register Member' : 'Login Member'; submit.value = registering ? 'Buat Akun' : 'Log In'; email.style.display = registering ? 'block' : 'none'; toggle.textContent = registering ? 'Sudah punya akun? Login' : 'Belum punya akun? Register'; }
    toggle.onclick = () => { registering = !registering; mode(); showMessage(''); };
    submit.onclick = () => {
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value;
      const users = readUsers();
      if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return showMessage('Username 3–24 karakter: huruf, angka, atau underscore.');
      if (registering) {
        if (username.toLowerCase() === 'sakz') return showMessage('Username Sakz khusus DEV dan tidak bisa didaftarkan.');
        if (password.length < 4) return showMessage('Password minimal 4 karakter.');
        if (users.some(u => String(u.username).toLowerCase() === username.toLowerCase())) return showMessage('Username sudah dipakai.');
        const newUser = { username, password, email: email.value.trim() || '—', userid: 'VOLT-' + Date.now().toString(36).toUpperCase(), role: 'MEMBER', status: 'Active', created_at: new Date().toLocaleDateString() };
        users.push(newUser); writeUsers(users); localStorage.setItem(SESSION_KEY, JSON.stringify({ username: newUser.username })); location.href = 'splash.html';
      } else {
        const found = users.find(u => String(u.username).toLowerCase() === username.toLowerCase() && u.password === password);
        if (!found) return showMessage('Username atau password salah.');
        localStorage.setItem(SESSION_KEY, JSON.stringify({ username: found.username })); location.href = 'splash.html';
      }
    };
    document.getElementById('password').addEventListener('keydown', e => { if (e.key === 'Enter') submit.click(); });
    mode();
  }
  function setupPage() {
    const path = location.pathname.split('/').pop();
    if (path === 'index.html' || path === '') { setupLogin(); return; }
    const user = requireLogin(); if (!user) return;
    document.querySelectorAll('[data-volt-username]').forEach(el => el.textContent = user.username);
    if (path === 'dashboard.html') {
      const heading = document.querySelector('.welcome-text'); if (heading) heading.textContent = 'Welcome back! ' + user.username;
      const nav = document.querySelector('.navbar');
      if (nav && user.role === 'DEV' && !document.getElementById('volt-members-link')) {
        const btn = document.createElement('button'); btn.id = 'volt-members-link'; btn.className = 'nav-item'; btn.innerHTML = '<span>👥</span>Members'; btn.onclick = () => location.href = 'members.html'; nav.appendChild(btn);
      }
      if (nav) { const logout = document.createElement('button'); logout.className = 'nav-item'; logout.innerHTML = '<span>↪️</span>Logout'; logout.onclick = logoutUser; nav.appendChild(logout); }
    }
    if (path === 'account.html') {
      const profile = document.querySelector('.profile-card');
      if (profile) profile.innerHTML = `<div class="avatar">🥷</div><h2>${safeText(user.username)}</h2><div class="status">● ${safeText(user.role)} Account</div>`;
      const rows = document.querySelectorAll('.info-row .value');
      const values = [user.username, '••••••••', user.email || '—', user.userid || '—', user.status || 'Active', user.role, user.created_at || '—'];
      rows.forEach((el, i) => { if (values[i] !== undefined) el.textContent = values[i]; });
      const back = document.querySelector('.back-button'); if (back) { back.insertAdjacentHTML('beforebegin', '<a class="back-button" href="#" id="volt-logout">Logout</a>'); document.getElementById('volt-logout').onclick = e => { e.preventDefault(); logoutUser(); }; }
    }
    if (path === 'members.html') setupMembers(user);
  }
  function setupMembers(user) {
    if (user.role !== 'DEV') { location.replace('dashboard.html'); return; }
    const list = document.getElementById('member-list'); if (!list) return;
    function render() {
      const users = readUsers();
      list.innerHTML = users.map(u => `<div class="member"><div><strong>${safeText(u.username)}</strong><p>${safeText(u.email || '—')} · ${safeText(u.role)}</p><small>${safeText(u.userid || '')}</small></div>${String(u.username).toLowerCase() === 'sakz' ? '<b>DEV</b>' : `<button data-delete="${safeText(u.username)}">Hapus</button>`}</div>`).join('');
      list.querySelectorAll('[data-delete]').forEach(btn => btn.onclick = () => { const name = btn.getAttribute('data-delete'); if (!confirm('Hapus akun ' + name + ' dari perangkat ini?')) return; writeUsers(readUsers().filter(u => String(u.username).toLowerCase() !== name.toLowerCase())); render(); });
    }
    render();
  }
  function logoutUser() { localStorage.removeItem(SESSION_KEY); location.href = 'index.html'; }
  ensureDev();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setupPage); else setupPage();
})();
