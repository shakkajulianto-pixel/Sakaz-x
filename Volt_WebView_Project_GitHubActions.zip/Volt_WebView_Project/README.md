# Volt Android WebView Project

Project Android untuk membungkus halaman HTML/CSS/JavaScript Volt menjadi APK menggunakan WebView.

## Build APK dari HP lewat GitHub Actions
1. Ekstrak ZIP ini di HP.
2. Buat repository baru di GitHub, misalnya `Volt-Android`.
3. Upload **isi folder `Volt_WebView_Project`** ke root repository (jangan upload folder induknya sebagai satu folder bertingkat).
4. Pastikan `.github/workflows/build-apk.yml` ikut ter-upload. Jika GitHub mobile tidak menampilkan folder tersembunyi, buat folder dan file tersebut di repository sesuai path itu.
5. Buka tab **Actions** di repository. Aktifkan Actions bila diminta.
6. Pilih workflow **Build Volt APK**, tekan **Run workflow**. Workflow juga berjalan otomatis setiap ada push ke `main`.
7. Tunggu sampai tanda centang hijau. Buka hasil run, scroll ke **Artifacts**, lalu download `Volt-debug-apk`.
8. Ekstrak hasil download dan instal `app-debug.apk`. Jika Android meminta izin, izinkan instalasi dari sumber tersebut.

Workflow menggunakan JDK 17, Android SDK 35, Gradle 8.9, lalu mengunggah APK debug sebagai artifact.

## Isi
- `app/src/main/assets/www/`: halaman web Volt dan `auth.js`.
- Login/register menyimpan akun lokal di WebView `localStorage`.
- Username `Sakz` dicadangkan sebagai DEV; register biasa mendapat role MEMBER.
- Halaman Members ditujukan untuk DEV dan mengelola daftar member lokal.

## Catatan
- Data akun tersimpan hanya pada instalasi/perangkat itu. Data tidak sinkron antarperangkat dan dapat hilang jika data aplikasi dihapus.
- Ini prototipe lokal. Role dan data yang hanya diperiksa di JavaScript tidak aman untuk sistem produksi.
- Ganti password DEV awal sebelum digunakan. Password bawaan saat ini ada di `app/src/main/assets/www/auth.js`.
